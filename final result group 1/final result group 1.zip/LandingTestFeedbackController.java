

public class LandingTestFeedbackController {

    public static void main(String[] args) {
        LandingModuleFeedbackController tester = new LandingModuleFeedbackController(1000, new Vector2D(0, 1250000), new Vector2D(0,0));
        tester.updateModule(0.5);
    }
}
